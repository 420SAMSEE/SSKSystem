// Runtime config for SSKratom-YMT Final
window.APP_CONFIG = {
  SHEET_URL: "https://docs.google.com/spreadsheets/d/11vhg37MbHRm53SSEHLsCI3EBXx5_meXVvlRuqhFteaY",
  HOOK_URL: "https://script.google.com/macros/s/AKfycbxXAaBlyCFRfdQa4jPk8YehSmXE07sn3tXg8kfdDGtDkMCSqRB4_DDIDiyit2tzDOSR/exec",
  DASHBOARD_URL: "https://script.google.com/macros/s/AKfycbwlaoF7kqjDbC5XQycWbd3e3uigG690slCbQ6YkaVolPmg22eEO9kAkrQMyCX4kx0jb",
  PRICE_PER_BOTTLE: 40
};
